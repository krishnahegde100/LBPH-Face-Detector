package lbph;

public class Params {
    public int radius;
    public int neighbours;
    public int gridX;
    public int gridY;

    public Params(int rad,int nei,int gx,int gy){
        this.radius=rad;
        this.neighbours=nei;
        this.gridX=gx;
        this.gridY=gy;
    }
}
