package Metric;

public class Metric {

   public static final String ChiSquare                    = "ChiSquare";
   public static final String EuclideanDistance            = "EuclideanDistance";
   public static final String NormalizedEuclideanDistance  = "NormalizedEuclideanDistance";
   public static final String AbsoluteValue                = "AbsoluteValue";

}
